
create database dioris;
use dioris;

create table loginn(
id int not null,
nombre varchar (20)not null,
apellido varchar (30)not null,
direccion varchar (30)not null,
cedula varchar (30)not null,
telefono varchar (30)not null,
celular varchar (30)not null,
usuario varchar (20)not null,
contrase�a varchar(30)not null,
)

create table loginnn(
id int not null,
nombre varchar (20)not null,
apellido varchar (30)not null,
direccion varchar (30)not null,
cedula varchar (30)not null,
telefono varchar (30)not null,
celular varchar (30)not null,
usuario varchar (20)not null,
contrase�a varchar(30)not null,
)

create table cliente(
IdProducto varchar (50),
Nombre varchar (20)not null,
Cantidad int not null,
Itbis varchar (30)not null,
Subtotal varchar (30)not null,
Total varchar (30)not null,
)

select*from cliente;




insert into loginn values (1,'Maria','Gil','27 Este','401-8957896-9','809-963-8956','829-895-8956','Administrador', 'itesa');
insert into loginnn values (2,'Jose','Romero','Los Prados','401-8857896-9','809-963-8956','829-895-8956','Maria8', 'amor');
select*from loginnn;
drop table loginn;


create table historial (
Fecha varchar (50),
Descripcion varchar (50),
Usuario varchar (50)
)
create trigger insertado
on producto for insert
AS
insert into historial values (getdate() , 'producto insertado por', system_user)

create trigger borrado
on producto for update
AS
insert into historial values (getdate() , 'producto desactivado por', system_user)

create trigger actualizado
on producto for update
AS
insert into historial values (getdate() , 'producto actualizado por', system_user)

create trigger usuarioinsertado
on loginn for insert
AS
insert into historial values (getdate() , 'Se registr� un usuario ', system_user)

create trigger actualizadoo
on loginn for update
AS
insert into historial values (getdate() , 'Se actualiz� un usuario por', system_user)

update producto set Nombre = 'Cama' where IdProducto = 'PROCT41'
select*from historial

create table producto (
 IdProducto varchar (50),
Nombre varchar(50),
Stock int not null,
Itbis varchar (50),
Subtotal varchar (50),
Total varchar (50),
Estado varchar (50),
Primary key (idproducto)
)
INSERT INTO producto VALUES              
                    ('PROCT1','Mueble',(100),'0.18','30000.00','35400','Activo'),
                    ('PROCT2','Mueble Caobal',(100),'0.18','45000.00','53100','Activo'),
                    ('PROCT3','Cama(ni�o/a)',(100),'0.18','10000.00','11800','Activo'),
                    ('PROCT4','Cama Adulto',(100),'0.18','25000.00','29500','Activo'),
                    ('PROCT5','Cama(ni�o/a) Caoba',(100),'0.18','18750.00','22125','Activo'),
                    ('PROCT6','Cama Adulto Caoba',(100),'0.18','32330.00','38149.4','Activo'),
                    ('PROCT8','Silla',(100),'0.18','3300.00','3894','Activo'),
                    ('PROCT9','Juego De Silla de Caoba',(100),'0.18','28500.00','33630','Activo'),
                    ('PROCT10','Silla De Caoba',(100),'0.18','5700.00','6726','Activo'),
                    ('PROCT11','Mesa',(100),'0.18','15000.00','17700','Activo'),
                    ('PROCT12','Mesa De Caoba',(100),'0.18','30000.00','35400','Activo'),
                    ('PROCT13','Meseta',(100),'0.18','7700.00','9086','Activo'),
                    ('PROCT14','Meseta De Caoba',(100),'0.18','14500.00','17110','Activo'),
                    ('PROCT15','Cajones',(100),'0.18','1000.00','1180','Activo'),
                    ('PROCT16','Cajones De Caoba',(100),'0.18','1500.00','1770','Activo'),
                    ('PROCT17','Mesedora',(100),'0.18','18000.00','21240','Activo'),
                    ('PROCT18','Mesedora De Caoba',(100),'0.18','26500.00','31270','Activo'),
                    ('PROCT19','Gabetero',(100),'0.18', '34000.00','40120','Activo'),
                    ('PROCT20','Gabetero De Caoba',(100),'0.18','55000.00','64900','Activo'),
                    ('PROCT21','Mesitas',(100),'0.18','16000.00','18880','Activo'),
                    ('PROCT22','Mesitas De Abedul',(100),'0.18','18000.00','21240','Activo'),
                    ('PROCT23','Silla de Abedul',(100),'0.18','3400.00','4012','Activo'),
                    ('PROCT24','Silla de Metal',(100),'0.18','6700.00','7,906','Activo'),
                    ('PROCT25','Cama(ni�o/a) Abedul',(100),'0.18', '20500.00','24190','Activo'),
                    ('PROCT26','Cama Adulto Abedul',(100),'0.18','10500.00','12390','Activo'),
                    ('PROCT27','Mueble Abedul',(100),'0.18','15500.00','18290','Activo'),
                    ('PROCT28','Juego de sillas Abedul',(100),'0.18','10500.00','12390','Activo'),
                    ('PROCT29','Mesa Abedul',(100),'0.18','5000','5900','Activo'),
                    ('PROCT30','Meseta de Abedul',(100),'0.18','3500.00','4130','Activo'),
                    ('PROCT31','Cajones de Abedul',(100),'0.18','1500.00','1770','Activo'),
                    ('PROCT32','Mesedora Abedul',(100),'0.18','2500.00','2950','Activo'),
                    ('PROCT33','Gabetero Abedul',(100),'0.18','5500.00','6490','Activo'),
                    ('PROCT34','Mesa Ebony',(100),'0.18','4500.00','5310','Activo'),
                    ('PROCT35','Meseta Ebony',(100),'0.18','3500.00','4130','Activo'),
                    ('PROCT36','Cajones Ebony',(100),'0.18','1500.00','1770','Activo'),
                    ('PROCT37','Mesita Ebony',(100),'0.18','2500.00','2950','Activo'),
                    ('PROCT38','Mesedora Ebony',(100),'0.18','5000.00','5900','Activo'),
                    ('PROCT39','Gabetero Ebony',(100),'0.18','45000.00','53100','Activo'),
                    ('PROCT40','Mesa Cristal',(100),'0.18','34000.00','40120','Activo'),
                    ('PROCT41','Mesita Cristal',(100),'0.18','28000.00','33040','Activo'),
                    ('PROCT42','Meseta Cristal',(100),'0.18','23000.00','27140','Activo'),
                    ('PROCT43','Mesa de Cafe Cristal',(100),'0.18','31900.00','37642','Activo'),
                    ('PROCT44','Mesedora Metal',(100),'0.18','30000.00','35400','Activo'),
                    ('PROCT45','Mesa de Roble',(100),'0.18','1500.00','1770','Activo'),
                    ('PROCT46','Meseta de Roble',(100),'0.18','45000.00','53100','Activo'),
                    ('PROCT47','Mesita de Roble',(100),'0.18','21500.00','25370','Activo'),
                    ('PROCT48','Gabetero de Roble',(100),'0.18','25500.0','30090','Activo'),
                    ('PROCT49','Silla de Roble',(100),'0.18','4500.0','5310','Activo'),
                    ('PROCT50','Cama(ni�o/a) Roble',(100),'0.18','26000.00','30680','Activo'),
                    ('PROCT51','Cama Adulto Roble',(100),'0.18','52000.00','61360','Activo'),
                    ('PROCT52','Cajones de Roble',(100),'0.18','5000.00','900','Activo'),
                    ('PROCT53','Banquitos de Roble',(100),'0.18','12000.00','14160','Activo'),
                    ('PROCT54','Banquitos de Ebony',(100),'0.18','9500.00','11210','Activo'),
                    ('PROCT55','Banquitos de Abedul',(100),'0.18','10000.00','11800','Activo'),
                    ('PROCT56','Juego de sala Sofisticado',(100),'0.18','30000.00','35400','Activo'),
                    ('PROCT57','Juego de Mesa (4 Piezas)',(100),'0.18','20000.00','23600','Activo'),
                    ('PROCT58','Juego de Mesas Anayi',(100),'0.18','55000.00','64900','Activo'),
                    ('PROCT59','Juego de Mesas Robert',(100),'0.18','30750.00','36285','Activo'),
                    ('PROCT60','Colchones ni�o/a pillowtop',(100),'0.18','10000.00','11800','Activo'),
                    ('PROCT61','Colchones (adulto) pillowtop',(100),'0.18','12000.00','14160','Activo'),
                    ('PROCT62','Mesa para pc (2 monitores)',(100),'0.18','20000.00','23600','Activo'),
                    ('PROCT64','Colchones Inflables',(100),'0.18','15000.00','17700','Activo'),
                    ('PROCT65','Lavamanos',(100),'0.18','20500.00','24190','Activo'),
                    ('PROCT66','Espejo (peque�o)',(100),'0.18','1200.00','1416','Activo'),
                    ('PROCT67','Estante plastico',(100),'0.18','1300.00','1534','Activo'),
                    ('PROCT68','Rack de sala Metal (4U)',(100),'0.18','2150.00','2537','Activo'),
                    ('PROCT69','Marco para fotos 5x5',(100),'0.18','1550.00','1829','Activo'),
                    ('PROCT70','Librero 10m de diametro Metal',(100),'0.18','34000.00','40120','Activo'),
                    ('PROCT71','Librero 10m de diametro Abedul',(100),'0.18','23000.00','27140','Activo'),
                    ('PROCT72','Librero 10m de diametro Ebony',(100),'0.18','28000.00','33040','Activo'),
                    ('PROCT73','Cuna Ebony',(100),'0.18','20000.00','23600','Activo'),
                    ('PROCT74','Cuna Caoba',(100),'0.18','25000.00','29500','Activo'),
                    ('PROCT75','Cuna Abedul',(100),'0.18','30000.00','35400','Activo'),
                    ('PROCT76','Cuna de Roble',(100),'0.18','50000.00','59000','Activo'),
                    ('PROCT77','Ventanales de cristal',(100),'0.18','35000.00','41300','Activo'),
                    ('PROCT78','Palos de cortinas',(100),'0.18','1500.00','1770','Activo'),
                    ('PROCT79','Palos de cortinas de Caoba',(100),'0.18','1600.00','1888','Activo'),
                    ('PROCT80','Palos de cortinas de Abedul',(100),'0.18','1700.00','2006','Activo'),
                    ('PROCT81','Palos de cortinas de Ebony',(100),'0.18','1800.00','2124','Activo'),
                    ('PROCT82','Palos de cortinas de Roble',(100),'0.18','1900.00','2242','Activo'),
                    ('PROCT83','Cortinas',(100),'0.18','3000.00','3540','Activo'),
                    ('PROCT84','Cortinas de Seda',(100),'0.18','35000.00','41300','Activo'),
                    ('PROCT85','Cortinas de tela',(100),'0.18','36000.00','42480','Activo'),
                    ('PROCT86','Aire a Condicionado LG',(100),'0.18','45000.00','53100','Activo'),
                    ('PROCT87','Aire a condicionado Samsung',(100),'0.18','50000.00','59000','Activo'),
                    ('PROCT88','Fuentes de agua de ceramica',(100), '0.18','70000.00','82600','Activo'),
                    ('PROCT89','Fuentes de agua de concreto',(100),'0.18','60000.00','70800','Activo'),
                    ('PROCT90','Fuentes de agua de yeso',(100),'0.18','100000.00','118000','Activo'),
                    ('PROCT91','Fuentes de agua de cristal con metal',(100),'0.18','400000.00','472000','Activo'),
                    ('PROCT92','Fuentes de agua de piedra',(100),'0.18','300000.00','354000','Activo'),
                    ('PROCT93','Estatuas de yeso para fuentes de agua',(100),'0.18','2000.00','2360','Activo'),
                    ('PROCT94','Estatuas de piedra para fuentes de agua',(100),'0.18','2500.00','2950','Activo'),
                    ('PROCT95','Vitrina de cristal',(100),'0.18','3000.00','3540','Activo'),
                    ('PROCT96','Pecera ',(100),'0.18','3000.00','3540','Activo'),
                    ('PROCT97','Camarote de Caoba',(100),'0.18','15000.00','17700','Activo'),
                    ('PROCT98','Camarote de Ebony',(100),'0.18','15000.00','17700','Activo'),
                    ('PROCT99','Camarote de Roble',(100),'0.18','15000.00','17700','Activo'),
                    ('PROCT100','Camarote de Metal',(100),'0.18','5000.00','5900','Activo')
                      select * from proveedores ;    
					  drop table proveedores; 

	create table proveedores (
IdProveedor varchar(12),
Nombre varchar(30),
Contacto varchar(50),
Direcci�n varchar(100),
C�digo_postal varchar(8),
Correo_Electronico varchar(100),
Estado varchar(20),
Primary key(IDproveedor)
)


INSERT INTO proveedores VALUES
                        ('PROO1','IKEA','8095674532','Av. John F. Kennedy Santo Domingo',546,'ikea@gmail.com','Activo')

create table conduce (
cliente varchar(30),
observaciones varchar(100),
Nota_d_conduce varchar(100),
fecha_ini DATE,
fecha_venci DATE,
Lista_d_precio varchar(60),
Tipo_d_Documento varchar(30)
)
                              
