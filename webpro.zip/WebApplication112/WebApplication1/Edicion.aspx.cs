﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class Edicion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Menu2.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {



        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from loginn where cedula='" + TextBox10.Text + "'", con);
            SqlDataReader leer = cmd.ExecuteReader();

            if (leer.Read())
            {
                TextBox19.Text = leer["id"].ToString();
                TextBox20.Text = leer["nombre"].ToString();
                TextBox13.Text = leer["apellido"].ToString();
                TextBox14.Text = leer["direccion"].ToString();
                TextBox15.Text = leer["telefono"].ToString();
                TextBox16.Text = leer["celular"].ToString();
                TextBox17.Text = leer["usuario"].ToString();
                TextBox18.Text = leer["contraseña"].ToString();



            }
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {

            {
                SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
                con.Open();
                SqlCommand cmd = new SqlCommand("update loginn set nombre='" + TextBox20.Text + "',apellido='" + TextBox13.Text + "', direccion='" + TextBox14.Text + "' ,telefono='" + TextBox15.Text + "',celular='" + TextBox16.Text + "',usuario='" + TextBox17.Text + "',contraseña='" + TextBox18.Text + "' where id='" + TextBox19.Text + "'", con);
                SqlDataReader leer = cmd.ExecuteReader();
                if (leer.Read())
                {
                    Label1.Text = ("Guardado");
                }

                else

                    Label1.Text = ("Guardado");
                con.Close();


            }
        }
    }
}
