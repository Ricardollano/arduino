﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace WebApplication1
{
    public partial class Proveedores : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand consulta = new SqlCommand(string.Format("SELECT * from proveedores where Estado='Activo'"), con);
            SqlDataAdapter da = new SqlDataAdapter(consulta);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            con.Close();
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            

        }

        protected void Button4_Click1(object sender, EventArgs e)
        {
            SqlConnection coon = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            coon.Open();

            SqlCommand com = new SqlCommand("select IdProveedor from proveedores where IdProveedor='" + TextBox1.Text + "';", coon);
            SqlDataReader leeer = com.ExecuteReader();
            if (leeer.Read())
            {
                Label7.Text = ("Ya existe un proveedor con este ID.");

                coon.Close();
            }
            else
            {




                SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into proveedores (IdProveedor, Nombre, Contacto,Dirección,Código_postal, Correo_Electronico ,Estado)values('" + TextBox1.Text + "','" + TextBox2.Text + "', '" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "'); ", con);
                SqlDataReader leer = cmd.ExecuteReader();
                if (leer.Read())
                {

                    Response.Redirect("Proveedores.aspx");

                }
                else
                    Response.Redirect("Proveedores.aspx");
            }
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            TextBox7.Text = "";



        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from proveedores where IdProveedor='" + TextBox1.Text + "'", con);
            SqlDataReader leer = cmd.ExecuteReader();

            if (leer.Read())
            {
                TextBox1.Text = leer["IdProveedor"].ToString();
                TextBox2.Text = leer["Nombre"].ToString();
                TextBox3.Text = leer["Contacto"].ToString();
                TextBox4.Text = leer["Dirección"].ToString();
                TextBox5.Text = leer["Código_postal"].ToString();
                TextBox6.Text = leer["Correo_Electronico"].ToString();
                TextBox7.Text = leer["Estado"].ToString();

            }
            else
                Label7.Text = ("Producto no encontrado.");

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand cmd = new SqlCommand("update proveedores set IdProveedor='" + TextBox1.Text + "',Nombre='" + TextBox2.Text + "',Contacto=" + TextBox3.Text + ", Dirección='" + TextBox4.Text + "', Código_postal='" + TextBox5.Text + "', Correo_Electronico='" + TextBox6.Text + "',Estado='" + TextBox7.Text + "' WHERE IdProveedor='" + TextBox1.Text + "';", con);
            cmd.ExecuteNonQuery();
            Response.Redirect("proveedores.aspx");
            con.Close();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand cmd = new SqlCommand("update proveedores set Estado='" + TextBox7.Text + "' where IdProveedor='" + TextBox1.Text + "';", con);
            cmd.ExecuteNonQuery();
            Response.Redirect("proveedores.aspx");
            con.Close();
        }
    }
    }
