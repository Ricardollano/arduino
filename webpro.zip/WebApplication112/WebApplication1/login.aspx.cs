﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Entrar_Click(object sender, EventArgs e)
        {
           
            
          
         
        

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registro.aspx");
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged1(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {



            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM loginn   WHERE usuario='" + TextBox1.Text + "' AND contraseña='" + TextBox2.Text + "' ", con);
            SqlDataReader leer = cmd.ExecuteReader();
            if (leer.Read())
            {

                if (TextBox1.Text == "Administrador") { Response.Redirect("Menu2.aspx");

                }
                else if (TextBox1.Text != "Administrador") { Response.Redirect("Menú Principal2.aspx"); }

            }
           
            
            
             
            
           
            else
            /*
             if (textbox.ejemplo == "Admin") { Response.Redirect(MenuAdmin.aspx); }
             else if (textbox.ejemplo != "Admin") { Response.Redirect(Menu.aspx); }
                 
             */
            {

                Label1.Text = ("Usuario o contraseña incorrecta");

            }

            con.Close();
            
        }
    }
}