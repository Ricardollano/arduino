﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication1
{
    public partial class historial : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand consulta = new SqlCommand(string.Format("SELECT * from historial"), con);
            SqlDataAdapter da = new SqlDataAdapter(consulta);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            con.Close();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}