﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication1
{
    public partial class Facturacion : System.Web.UI.Page

    {
        string b;
        double mult;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Params["parametro"] != null)
            {
                Label5.Text = Request.Params["parametro"];
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand consulta = new SqlCommand(string.Format("SELECT IdProducto, Nombre,Itbis,Subtotal,Total from producto where IdProducto='" + TextBox1.Text + "'"), con);
            SqlDataAdapter da = new SqlDataAdapter(consulta);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
         
            con.Close();
            {
                SqlConnection conn = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
                conn.Open();
                SqlCommand cmdd = new SqlCommand("Select Total from producto where IdProducto='" + TextBox1.Text + "'", conn);
                SqlDataReader leerr = cmdd.ExecuteReader();

                if (leerr.Read())
                {
                    Label2.Text = leerr["Total"].ToString();
                    b = leerr["Total"].ToString();
                    mult =Convert.ToInt32( b) * Convert.ToInt32(TextBox2.Text);
                    Label2.Text = mult.ToString();

                }
                else
                    Label6.Text = ("Producto no encontrado.");






            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            
                

                        Label7.Text = ("Pagado");

                    }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Label7.Text = ("Pagado");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Label7.Text = ("Pagado");
        }
    }
        
    }
