﻿namespace WebApplication1
{
}

namespace WebApplication1
{


    public partial class DataSet1
    {
    }
}
