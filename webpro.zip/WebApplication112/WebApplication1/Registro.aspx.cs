﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


namespace WebApplication1
{
    public partial class Registro : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand cmd = new SqlCommand(" SELECT MAX(id)+1 as id from loginn;", con);
            SqlDataReader leer = cmd.ExecuteReader();

            if (leer.Read())
            {
                TextBox10.Text = leer["id"].ToString();

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
        }





        protected void TextBox8_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            Response.Redirect("Menu2.aspx");
        }

        protected void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            SqlConnection coon = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            coon.Open();

            SqlCommand com = new SqlCommand("select cedula from loginn where cedula='" + TextBox14.Text + "';", coon);
            SqlDataReader leeer = com.ExecuteReader();
            if (leeer.Read())
            {
                Label1.Text = ("Ya existe un persona con esta cedula");

                coon.Close();

            }
            else
            {
                SqlConnection ccon = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
                ccon.Open();

                SqlCommand ccom = new SqlCommand("select usuario from loginn where usuario='" + TextBox17.Text + "';", ccon);
                SqlDataReader lleeer = ccom.ExecuteReader();
                if (lleeer.Read())
                {
                    Label1.Text = ("Ya existe un persona con este usuario");

                    ccon.Close();

                }
                else
                {
                    SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into loginn (id, nombre, apellido, direccion, cedula,telefono,celular, usuario,contraseña)values('" + TextBox10.Text + "','" + TextBox19.Text + "', '" + TextBox20.Text + "','" + TextBox13.Text + "','" + TextBox14.Text + "', '" + TextBox15.Text + "', '" + TextBox16.Text + "', '" + TextBox17.Text + "', '" + TextBox18.Text + "' ); ", con);
                    SqlDataReader leer = cmd.ExecuteReader();
                    if (leer.Read())
                    {

                        Label1.Text = ("Guardado");

                    }
                    else

                        Label1.Text = ("Guardado");
                    con.Close();
                }
            }
        }

        protected void Button2_Click2(object sender, EventArgs e)
        {

        }

    }

}