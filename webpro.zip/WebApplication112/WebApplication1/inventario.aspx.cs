﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace WebApplication1
{
    public partial class inventario : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand consulta = new SqlCommand(string.Format("SELECT * from producto where Estado='Activo'"), con);
            SqlDataAdapter da = new SqlDataAdapter(consulta);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            con.Close();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            SqlConnection coon = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            coon.Open();

            SqlCommand com = new SqlCommand("select IdProducto from producto where IdProducto='" + TextBox1.Text + "';", coon);
            SqlDataReader leeer = com.ExecuteReader();
            if (leeer.Read())
            {
                Label7.Text = ("Ya existe un producto con este ID.");

                coon.Close();
            }
            else
            {




                SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into producto (Idproducto, Nombre, Stock,Itbis,Subtotal, Total,Estado)values('" + TextBox1.Text + "','" + TextBox2.Text + "', '" + TextBox3.Text + "','" + TextBox6.Text + "','" + TextBox4.Text + "','" + TextBox7.Text + "','" + TextBox5.Text + "'); ", con);
                SqlDataReader leer = cmd.ExecuteReader();
                if (leer.Read())
                {

                    Response.Redirect("inventario.aspx");

                }
                else
                    Response.Redirect("inventario.aspx");
            }
            TextBox1.Text="";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            TextBox7.Text = "";

        }

        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {
           
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            
          

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
          
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
           

        }

        protected void Button5_Click1(object sender, EventArgs e)
        {
            
        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from producto where IdProducto='" + TextBox1.Text + "'", con);
            SqlDataReader leer = cmd.ExecuteReader();

            if (leer.Read())
            {
                TextBox1.Text = leer["IdProducto"].ToString();
                TextBox2.Text = leer["Nombre"].ToString();
                TextBox3.Text = leer["Stock"].ToString();
                TextBox6.Text = leer["Itbis"].ToString();
                TextBox4.Text = leer["Subtotal"].ToString();
                TextBox5.Text = leer["Total"].ToString();
                TextBox7.Text = leer["Estado"].ToString();
                
            }
            else
                Label7.Text = ("Producto no encontrado.");

        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand cmd = new SqlCommand("update producto set IdProducto='" + TextBox1.Text + "',Nombre='" + TextBox2.Text + "',Stock=" + TextBox3.Text + ", Itbis='" + TextBox6.Text + "', Subtotal='" + TextBox4.Text + "', Total='" + TextBox7.Text + "',Estado='" + TextBox5.Text + "' WHERE IdProducto='" + TextBox1.Text + "';", con);
            cmd.ExecuteNonQuery();
            Response.Redirect("inventario.aspx");
            con.Close();
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("workstation id=dioris000.mssql.somee.com;packet size=4096;user id=ricardollano_SQLLogin_1;pwd=9kjwdlhmpj;data source=dioris000.mssql.somee.com;persist security info=False;initial catalog=dioris000");
            con.Open();
            SqlCommand cmd = new SqlCommand("update producto set Estado='" + TextBox5.Text + "' where IdProducto='"+TextBox1.Text+"';", con);
            cmd.ExecuteNonQuery();
            Response.Redirect("inventario.aspx");
            con.Close();
        }
    }
}